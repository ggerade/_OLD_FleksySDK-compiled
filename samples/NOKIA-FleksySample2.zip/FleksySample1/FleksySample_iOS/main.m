//
//  main.m
//  FleksySample_iOS
//
//  Created by Kosta Eleftheriou on 3/25/13.
//  Copyright (c) 2013 Syntellia. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
