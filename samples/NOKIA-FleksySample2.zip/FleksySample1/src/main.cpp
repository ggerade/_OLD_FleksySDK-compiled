
#import "FleksyTester.h"

int main(int argc, const char * argv[]) {
  
  FleksyTester::run("FleksyResources/en-US/");
  
  return 0;
}