//
//  FleksyTester.h
//  FleksySample1
//
//  Created by Kosta Eleftheriou on 3/25/13.
//  Copyright (c) 2013 Syntellia. All rights reserved.
//

#ifndef __FleksySample1__FleksyTester__
#define __FleksySample1__FleksyTester__

class FleksyTester {
public:
  static void run(const char* resourcePath);
};

#endif /* defined(__FleksySample1__FleksyTester__) */
