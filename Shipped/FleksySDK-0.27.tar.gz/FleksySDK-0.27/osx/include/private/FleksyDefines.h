//
//  FleksySettings.h
//  FleksyServer
//
//  Created by Kostas Eleftheriou on 12/7/12.
//  Copyright (c) 2012 Syntellia Inc. All rights reserved.
//

#define FLEKSY_SDK 0

#define BACK_TO_LETTERS ('\t'+2)
#define KEY_MAX_VALUE 256

